package com.example.homework3.SQl

object DBConfig {
    const val version = 1
    const val appDb = "APP_DB"
}